# TURKTV 
[![Telegram Group](https://img.shields.io/endpoint?color=neon&style=flat-square&url=https%3A%2F%2Ftg.sumanjay.workers.dev%2FTURKTVNET)](https://t.me/TURKTVNET)

Collection of publicly available IPTV channels from Turkey. 

Internet Protocol television (IPTV) is the delivery of television content over Internet Protocol (IP) networks.

## Usage

### Kodi (recommended)
I'm maintaining Turkish channels on [Catch-up TV & More](https://catch-up-tv-and-more.github.io/). You can download it on your device and start watching.

### M3U PLAYLIST
To watch IPTV just paste this link <https://itasli.github.io/TURKTV/index.m3u> to any player with M3U-playlists support or download it.

### Roku
Roku channel is available you can download it on your device using this link : <https://my.roku.com/account/add/LPNQZPK> !
